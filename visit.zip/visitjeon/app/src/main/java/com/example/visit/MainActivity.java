package com.example.visit;

import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    LinearLayout layout;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout=findViewById(R.id.scroll_layout);

        int but = (int)(layout.getWidth()-dpToPx(this, 2))/3;
        for (int i = 0; i < 9; i++) {
            if (i%2==0) {
                Button button = new Button(this);
                button.setLayoutParams(new LinearLayout.LayoutParams(but, LinearLayout.LayoutParams.MATCH_PARENT));
                button.setText("button "+i);
                layout.addView(button);

            }
            else {
                View bar = new View(this);
                bar.setLayoutParams(new LinearLayout.LayoutParams((int)dpToPx(this, 1), LinearLayout.LayoutParams.MATCH_PARENT));
                bar.setBackgroundColor(getColor(R.color.black));
                layout.addView(bar);
            }
        }

    }

    public float dpToPx(Context context, float dp) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, dm);
    }
}
